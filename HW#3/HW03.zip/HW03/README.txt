README

作者資訊
電機一 許秉鈞
B03901023

"I FINISHED THE BONUS PART!"

編譯環境
g++ on cygwin64 (Windows x64)
CPPFLAGS = -O2 -std=c++11 -Wall

設置指引
根據makefile指示如下:

make
./hw3_1
./hw3_2


檔案列表（隨著軟件而發佈的檔案）

cipher.cpp
decipher.cpp
bonus.cpp
makefile
README.txt

已知臭蟲
暫無

更新記錄

【2014.04.27】
作業完成

花費時間
約10hrs

網站資源
Cplusplus.com

特別感謝
謝明倫助教、Paul、Eddy