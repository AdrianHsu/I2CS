README

作者資訊
電機一 許秉鈞
B03901023

"I FINISHED THE BONUS PART!"

編譯環境
g++ on OS X bash
CPPFLAGS = -O2 -std=c++11 -Wall

設置指引
根據makefile指示如下:


基礎題：
請將主執行檔命名為main.cpp, 
並 #include "myvector.h"
接著依照以下指令
1. make hw5 
2. ./hw5

BONUS：
請將主執行檔命名為t_main.cpp, 
並 #include "myvector.h" "tvector.h" 與 "tvector.cpp"
接著依照以下指令
1. make bonus
2. ./bonus

檔案列表

myvector.h
myvector.cpp
tvector.h
tvector.cpp
sroot.pl
gcd.pl
makefile
README.md

已知臭蟲
暫無

更新記錄

【2015.05.25】
作業完成

花費時間
約20hrs

網站資源
Cplusplus.com

特別感謝
謝明倫助教

