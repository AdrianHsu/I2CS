/*
 * File:   camera.h
 * Author: Tian-Li Yu
 *
 * Viewpoint fixed at (0,0,distance)
 * Viewplance fixed at (0,0,distance-1)
 * Target fixed at (0,0,0)
 */

#ifndef CAMERA_H
#define CAMERA_H

#include "point3.h"

class Camera {
public:
    Camera(double _distance, double _zoom) {
        distance = _distance;
        zoom = _zoom;
    }

    Point3 vector() const {
        Point3 result;
        result.x = 0;
        result.y = 0;
        result.z = 1;
        return result;
    }

    Point3 convert(const Point3& p) const {
        double td = distance - p.z;

        Point3 result;
        result.x = p.x / td * zoom;
        result.y = p.y / td * zoom;
        result.z = p.z;

        return result;
    }

protected:
    double distance;
    double zoom;

};

#endif /* CAMERA_H */

