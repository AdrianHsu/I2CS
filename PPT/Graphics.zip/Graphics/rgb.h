
#ifndef RGB_H
#define RGB_H


class RGB {
public:
    RGB(double _r=0, double _g=0, double _b=0) {
        r = _r;
        g = _g;
        b = _b;
    }

    RGB operator* (double s) const {
        RGB result;
        result.r = r*s;
        result.g = g*s;
        result.b = b*s;
        return result;
    }

    RGB operator+ (const RGB& c) const {
        RGB result;
        result.r = r + c.r;
        result.g = g + c.g;
        result.b = b + c.b;
        return result;
    }

    RGB operator- (const RGB& c) const {
        RGB result;
        result.r = r - c.r;
        result.g = g - c.g;
        result.b = b - c.b;
        return result;
    }


    double r;
    double g;
    double b;
};


#endif /* RGB_H*/
