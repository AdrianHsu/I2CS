/*
 * File:   bplan.h
 * Author: Tian-Li Yu
 *
 * Last updated on 2012/04/30
 * For I2CS course
 *
 */

#ifndef TRIANGLE_H
#define TRIANGLE_H

class Triangle {
public:
    void init(int a, int b, int c) {
        v0 = a;
        v1 = b;
        v2 = c;
    }

    int operator[] (int index) const {
        if (index == 0) return v0;
        if (index == 1) return v1;
        return v2;
    }

protected:
    int v0;
    int v1;
    int v2;

};

#endif  /* TRIANGLE_H */

