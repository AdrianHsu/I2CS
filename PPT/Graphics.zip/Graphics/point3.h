/*
 * File:   point3.h
 * Author: Tian-Li Yu
 *
 */

#ifndef POINT3_H
#define POINT3_H

#include <cmath>

class Point3 {
public:
    Point3(double _x = 0, double _y = 0, double _z = 0) {
        x = _x;
        y = _y;
        z = _z;
    }
    double x;
    double y;
    double z;

    double operator[] (int index) const {
        if (index == 0) return x;
        if (index == 1) return y;
        return z;
    }

    Point3 operator+ (const Point3& p) const {
        Point3 result;
        result.x = x + p.x;
        result.y = y + p.y;
        result.z = z + p.z;
        return result;
    }

    Point3 operator- (const Point3& p) const {
        Point3 result;
        result.x = x - p.x;
        result.y = y - p.y;
        result.z = z - p.z;
        return result;
    }

    // scalar multiplication
    Point3 operator* (double s) const {
        Point3 result;
        result.x = x * s;
        result.y = y * s;
        result.z = z * s;
        return result;
    }

    // inner product
    double operator* (const Point3& p) const {
        double result;
        result = x * p.x + y * p.y + z * p.z;
        return result;
    }

    // cross product
    Point3 operator^ (const Point3& p) const {
        Point3 result;
        result.x = y * p.z - z * p.y;
        result.y = z * p.x - x * p.z;
        result.z = x * p.y - y * p.x;
        return result;
    }

    // normalize
    void normalize () {
        double n = sqrt(x*x + y*y + z*z);
        if (n>0) {
            x /= n;
            y /= n;
            z /= n;
        } else {
            x = 0.0;
            y = 0.0;
            z = 0.0;
        }
    }

};


#endif  /* POINT3_H */

