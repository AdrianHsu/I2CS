
#ifndef TRIOBJ_H
#define TRIOBJ_H

#include <iostream>
#include <stdio.h>

using namespace std;

#include "baseobj.h"
#include "bitmap.h"
#include "camera.h"
#include "light.h"
#include "point3.h"
#include "triangle.h"


int comp(const void* a, const void* b) {
    typedef struct {
        int index;
        double z;
    } MyZ;


    if (((MyZ*)a)->z > ((MyZ*)b)->z)
        return 1;
    else if (((MyZ*)a)->z < ((MyZ*)b)->z)
        return -1;

    return 0;
}

class TriObj: public BaseObj {

    friend class BezObj;

public:
    TriObj(const char* filename) {
        FILE *fp = fopen(filename, "r");
        fscanf(fp,"%i\n", &tNum);
        triangle = new Triangle[tNum];
        for (int i=0; i<tNum; ++i) {
            int a, b, c;
            fscanf(fp, "%i,%i,%i\n", &a, &b, &c);
            triangle[i].init(a,b,c);
        }
        fscanf(fp,"%i\n", &vNum);
        vertex = new Point3[vNum];
        center = new Point3[tNum];
        norm = new Point3[tNum];
        vNorm = new Point3[vNum];

        for (int i=0; i<vNum; ++i) {
            double x, y, z;
            fscanf(fp, "%lf,%lf,%lf\n", &x, &y, &z);
            vertex[i].x = x;
            vertex[i].y = y;
            vertex[i].z = z;
        }
        fclose(fp);
        computed = false;
    }

    TriObj(int _vNum = 0, int _tNum = 0): BaseObj(_vNum) {
        init(_vNum, _tNum);
    }

    void init(int _vNum = 0, int _tNum = 0) {

        computed = false;
        if (vNum != _vNum) {
            if (vertex != NULL) delete []vertex;
            vNum = _vNum;
            vertex = new Point3[vNum];
        }

        tNum = _tNum;
        if (tNum != 0) {
            triangle = new Triangle[tNum];
            center = new Point3[tNum];
            norm = new Point3[tNum];
            vNorm = new Point3[vNum];
        } else {
            triangle = NULL;
            center = NULL;
            norm = NULL;
            vNorm = NULL;
        }
    }


    ~TriObj() {
        if (triangle != NULL) delete []triangle;
        if (center != NULL) delete []center;
        if (norm != NULL) delete []norm;
        if (vNorm != NULL) delete []vNorm;
    }

    void drawFlat(const Camera& camera, const Light& light, Bitmap& bmp) {
        typedef struct {
            int index;
            double z;
        } MyZ;

        computeAll();
        MyZ *myZ = new MyZ[tNum];
        for (int i=0; i<tNum; ++i) {
            Point3 v0 = camera.convert(vertex[triangle[i][0]]);
            Point3 v1 = camera.convert(vertex[triangle[i][1]]);
            Point3 v2 = camera.convert(vertex[triangle[i][2]]);
            myZ[i].index = i;
            myZ[i].z = v0.z + v1.z + v2.z;
        }


        qsort(myZ, tNum, sizeof(MyZ), comp);

        for (int i=0; i<tNum; ++i) {
            drawTriangleFlat(myZ[i].index, camera, light, bmp);
        }


        delete []myZ;
    }

    void drawGouraud(const Camera& camera, const Light& light, Bitmap& bmp) {
        typedef struct {
            int index;
            double z;
        } MyZ;

        computeAll();
        MyZ *myZ = new MyZ[tNum];
        for (int i=0; i<tNum; ++i) {
            Point3 v0 = camera.convert(vertex[triangle[i][0]]);
            Point3 v1 = camera.convert(vertex[triangle[i][1]]);
            Point3 v2 = camera.convert(vertex[triangle[i][2]]);
            myZ[i].index = i;
            myZ[i].z = v0.z + v1.z + v2.z;
        }


        qsort(myZ, tNum, sizeof(MyZ), comp);

        for (int i=0; i<tNum; ++i) {
            drawTriangleGouraud(myZ[i].index, camera, light, bmp);
        }


        delete []myZ;
    }

    void drawPhong(const Camera& camera, const Light& light, Bitmap& bmp) {
        typedef struct {
            int index;
            double z;
        } MyZ;

        computeAll();
        MyZ *myZ = new MyZ[tNum];
        for (int i=0; i<tNum; ++i) {
            Point3 v0 = camera.convert(vertex[triangle[i][0]]);
            Point3 v1 = camera.convert(vertex[triangle[i][1]]);
            Point3 v2 = camera.convert(vertex[triangle[i][2]]);
            myZ[i].index = i;
            myZ[i].z = v0.z + v1.z + v2.z;
        }


        qsort(myZ, tNum, sizeof(MyZ), comp);

        for (int i=0; i<tNum; ++i) {
            drawTrianglePhong(myZ[i].index, camera, light, bmp);
        }


        delete []myZ;
    }

    void drawFrame(const Camera& camera, Bitmap& bmp) const {
        for (int i=0; i<tNum; ++i)
            drawTriangleFrame(i, camera, bmp);
    }

protected:

    void computeAll() {
        if (computed) return;
        for (int i=0; i<tNum; ++i) {
            Triangle tri = triangle[i];
            norm[i] = (vertex[tri[2]] - vertex[tri[1]]) ^ (vertex[tri[0]] - vertex[tri[1]]);
            norm[i].normalize();
            center[i] = (vertex[tri[0]] + vertex[tri[1]] + vertex[tri[2]]) * 0.33333;
        }

        for (int i=0; i<vNum; ++i)
            vNorm[i].x = vNorm[i].y = vNorm[i].z = 0.0;


        for (int i=0; i<tNum; ++i) {
            Triangle tri = triangle[i];
            vNorm[tri[0]] = vNorm[tri[0]] + norm[i];
            vNorm[tri[1]] = vNorm[tri[1]] + norm[i];
            vNorm[tri[2]] = vNorm[tri[2]] + norm[i];
        }

        for (int i=0; i<vNum; ++i)
            vNorm[i].normalize();


        computed = true;

    }

    RGB computeColor(const Camera& camera, const Light& light, const Point3& norm, const Point3& pos) const {

        if (norm * camera.vector() < 0) return RGB(0,0,0);

        Point3 reflect = norm * (2 *(norm * light.vector())) - light.vector();
        // Spectular
        double ps = reflect * camera.vector();
        // Diffuse
        double pd = norm * light.vector();


        if (ps < 0) ps = 0;
        if (pd < 0) pd = 0;

        double Ia = light.getAmbient();
        double Id = light.getIntensity(pos);
        double total_1 = Ia + (1-Ia) * Id * ( kd * pd );
        double total_2 = (1-Ia) * Id * ( ks * pow(ps, s));

        // color of light
        RGB ci = light.color();

        double r = total_1 * color.r + total_2 * ci.r;
        double g = total_1 * color.g + total_2 * ci.g;
        double b = total_1 * color.b + total_2 * ci.b;
        if (r < 0.0) r = 0.0;
        if (g < 0.0) g = 0.0;
        if (b < 0.0) b = 0.0;

        return RGB(r, g, b);

    }

    void drawTriangleFlat(int index, const Camera& camera, const Light& light, Bitmap& bmp) const {


        Triangle tri = triangle[index];
        if (tri[1] == tri[0]) return;
        if (tri[2] == tri[0]) return;
        if (tri[1] == tri[2]) return;


        if (norm[index] * camera.vector() < 0) return;

        RGB c = computeColor(camera, light, norm[index], center[index]);

        Point3 v0 = camera.convert(vertex[tri[0]]);
        Point3 v1 = camera.convert(vertex[tri[1]]);
        Point3 v2 = camera.convert(vertex[tri[2]]);

        bmp.drawSolidTriangle(v0, v1, v2, c);
    }

    void drawTriangleGouraud(int index, const Camera& camera, const Light& light, Bitmap& bmp) {


        Triangle tri = triangle[index];
        if (tri[1] == tri[0]) return;
        if (tri[2] == tri[0]) return;
        if (tri[1] == tri[2]) return;


        if (norm[index] * camera.vector() < 0) return;

        RGB c0 = computeColor(camera, light, vNorm[tri[0]], vertex[tri[0]]);
        RGB c1 = computeColor(camera, light, vNorm[tri[1]], vertex[tri[1]]);
        RGB c2 = computeColor(camera, light, vNorm[tri[2]], vertex[tri[2]]);
        Point3 v0 = camera.convert(vertex[tri[0]]);
        Point3 v1 = camera.convert(vertex[tri[1]]);
        Point3 v2 = camera.convert(vertex[tri[2]]);

        double x0 = v0.x, y0=v0.y;
        double x1 = v1.x, y1=v1.y;
        double x2 = v2.x, y2=v2.y;

        if (y1 < y0) {
            swap (y0, y1);
            swap (x0, x1);
            swap (c0, c1);
        }
        if (y2 < y1) {
            swap (y1, y2);
            swap (x1, x2);
            swap (c1, c2);
        }
        if (y2 < y0) {
            swap (y0, y2);
            swap (x0, x2);
            swap (c0, c2);
        }
        if (y1 < y0) {
            swap (y0, y1);
            swap (x0, x1);
            swap (c0, c1);
        }

        double dx0 = x1 - x0;
        double dy0 = y1 - y0;
        double dx1 = x2 - x1;
        double dy1 = y2 - y1;
        double dx2 = x0 - x2;
        double dy2 = y0 - y2;

        double d0 = (fabs(dy0) > 1e-4)? dx0/dy0 : 0.0;
        double d1 = (fabs(dy1) > 1e-4)? dx1/dy1 : 0.0;
        double d2 = (fabs(dy2) > 1e-4)? dx2/dy2 : 0.0;

        double sx, ex;
        for (int i = (int)(y0+0.5); i < (int)(y1+0.5); ++i) {
            double id = i;
            if (id < y0) id = y0;
            if (id > y1) id = y1;

            RGB sc = (c0 * (y2-id) + c2 * (id-y0)) * (1.0/(y2-y0));
            RGB ec = (c0 * (y1-id) + c1 * (id-y0)) * (1.0/(y1-y0));

            sx = x0 + ((id-y0) * d2);
            ex = x0 + ((id-y0) * d0);

            if (sx > ex) {
                swap(sx,ex);
                swap(sc,ec);
            }

            RGB dc = (ec - sc) * (1.0/(ex-sx));
            RGB c = sc;

            for (int j = (int) (sx+0.5); j <= (int) (ex+0.5); ++j) {
                if (j == (int) (ex+0.5))
                    c = ec;
                bmp.setPixel(j,i,c);
                c = c + dc;
            }
        }

        for (int i = (int)(y1+0.5); i <= (int)(y2+0.5); ++i) {
            double id = i;
            if (id < y1) id = y1;
            if (id > y2) id = y2;

            RGB sc = (c0 * (y2-id) + c2 * (id-y0)) * (1.0/(y2-y0));
            RGB ec = (c1 * (y2-id) + c2 * (id-y1)) * (1.0/(y2-y1));

            sx = x0 + ((id-y0) * d2);
            ex = x1 + ((id-y1) * d1);
            if (sx > ex) {
                swap(sx,ex);
                swap(sc,ec);
            }
            RGB dc = (ec - sc) * (1.0/(ex-sx));
            RGB c = sc;
            for (int j = (int) (sx+0.5); j <= (int) (ex+0.5); ++j) {
                if (j == (int) (ex+0.5))
                    c = ec;
                bmp.setPixel(j,i,c);
                c = c + dc;
            }

        }

    }


    void drawTrianglePhong(int index, const Camera& camera, const Light& light, Bitmap& bmp) {


        Triangle tri = triangle[index];
        if (tri[1] == tri[0]) return;
        if (tri[2] == tri[0]) return;
        if (tri[1] == tri[2]) return;


        if (norm[index] * camera.vector() < 0) return;

        Point3 n0 = vNorm[tri[0]];
        Point3 n1 = vNorm[tri[1]];
        Point3 n2 = vNorm[tri[2]];
        Point3 v0 = camera.convert(vertex[tri[0]]);
        Point3 v1 = camera.convert(vertex[tri[1]]);
        Point3 v2 = camera.convert(vertex[tri[2]]);

        double x0 = v0.x, y0=v0.y;
        double x1 = v1.x, y1=v1.y;
        double x2 = v2.x, y2=v2.y;

        if (y1 < y0) {
            swap (y0, y1);
            swap (x0, x1);
            swap (n0, n1);
        }
        if (y2 < y1) {
            swap (y1, y2);
            swap (x1, x2);
            swap (n1, n2);
        }
        if (y2 < y0) {
            swap (y0, y2);
            swap (x0, x2);
            swap (n0, n2);
        }
        if (y1 < y0) {
            swap (y0, y1);
            swap (x0, x1);
            swap (n0, n1);
        }

        double dx0 = x1 - x0;
        double dy0 = y1 - y0;
        double dx1 = x2 - x1;
        double dy1 = y2 - y1;
        double dx2 = x0 - x2;
        double dy2 = y0 - y2;

        double d0 = (fabs(dy0) > 1e-4)? dx0/dy0 : 0.0;
        double d1 = (fabs(dy1) > 1e-4)? dx1/dy1 : 0.0;
        double d2 = (fabs(dy2) > 1e-4)? dx2/dy2 : 0.0;

        double sx, ex;
        for (int i = (int)(y0+0.5); i < (int)(y1+0.5); ++i) {
            double id = i;
            if (id < y0) id = y0;
            if (id > y1) id = y1;

            Point3 sn = (n0 * (y2-id) + n2 * (id-y0)) * (1.0/(y2-y0));
            Point3 en = (n0 * (y1-id) + n1 * (id-y0)) * (1.0/(y1-y0));

            sx = x0 + ((id-y0) * d2);
            ex = x0 + ((id-y0) * d0);

            if (sx > ex) {
                swap(sx,ex);
                swap(sn,en);
            }

            Point3 dn = (en - sn) * (1.0/(ex-sx));
            Point3 n = sn;

            for (int j = (int) (sx+0.5); j <= (int) (ex+0.5); ++j) {
                if (j == (int) (ex+0.5))
                    n = en;
                RGB c = computeColor(camera, light, n, center[i]);
                bmp.setPixel(j,i,c);
                n = n + dn;
            }
        }

        for (int i = (int)(y1+0.5); i <= (int)(y2+0.5); ++i) {
            double id = i;
            if (id < y1) id = y1;
            if (id > y2) id = y2;

            Point3 sn = (n0 * (y2-id) + n2 * (id-y0)) * (1.0/(y2-y0));
            Point3 en = (n1 * (y2-id) + n2 * (id-y1)) * (1.0/(y2-y1));

            sx = x0 + ((id-y0) * d2);
            ex = x1 + ((id-y1) * d1);
            if (sx > ex) {
                swap(sx,ex);
                swap(sn,en);
            }
            Point3 dn = (en - sn) * (1.0/(ex-sx));
            Point3 n = sn;
            for (int j = (int) (sx+0.5); j <= (int) (ex+0.5); ++j) {
                if (j == (int) (ex+0.5))
                    n = en;
                RGB c = computeColor(camera, light, n, center[i]);
                bmp.setPixel(j,i,c);
                n = n + dn;
            }

        }

    }

    void drawTriangleFrame(int index, const Camera& camera, Bitmap& bmp) const {
        Triangle tri = triangle[index];
        RGB c(255,255,255);
        Point3 v0 = camera.convert(vertex[tri[0]]);
        Point3 v1 = camera.convert(vertex[tri[1]]);
        Point3 v2 = camera.convert(vertex[tri[2]]);
        bmp.drawLine(v0, v1, c);
        bmp.drawLine(v1, v2, c);
        bmp.drawLine(v2, v0, c);
    }

private:
    template <class T>
    void swap(T& a, T& b) {
        T temp;
        temp = a;
        a = b;
        b = temp;
    }

protected:
    Triangle *triangle;
    int tNum;
    Point3 *center;
    Point3 *norm;
    Point3 *vNorm;
    bool computed;
};


#endif /* TRIOBJ_H */


