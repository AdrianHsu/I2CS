
#ifndef BASEOBJ_H
#define BASEOBJ_H

#include <iostream>

using namespace std;

#include "bitmap.h"
#include "camera.h"
#include "point3.h"

class BaseObj {

    friend class BezObj;

public:
    BaseObj(int _vNum = 0) {
        vNum = _vNum;
        if (vNum == 0)
            vertex = NULL;
        else
            vertex = new Point3[vNum];
    }

    ~BaseObj() {
        if (vertex != NULL)
            delete []vertex;
    }

    void setProperty(double _kd, double _s, const RGB& _color) {
        kd = _kd;
        ks = (1-kd);
        s = _s;
        color = _color;
    }

    void translate(double x, double y, double z) {
        for (int i = 0; i < vNum; ++i) {
            vertex[i].x += x;
            vertex[i].y += y;
            vertex[i].z += z;
        }
    }

    void rotateZ(double theta) {
        for (int i = 0; i < vNum; ++i) {
            double rad = theta * 3.1416 / 180.0;
            double x = vertex[i].x;
            double y = vertex[i].y;
            vertex[i].x = cos(rad)*x - sin(rad)*y;
            vertex[i].y = sin(rad)*x + cos(rad)*y;
        }
    }

    void rotateX(double theta) {
        for (int i = 0; i < vNum; ++i) {
            double rad = theta * 3.1416 / 180.0;
            double y = vertex[i].y;
            double z = vertex[i].z;
            vertex[i].y = cos(rad)*y - sin(rad)*z;
            vertex[i].z = sin(rad)*y + cos(rad)*z;
        }
    }

    void rotateY(double theta) {
        for (int i = 0; i < vNum; ++i) {
            double rad = theta * 3.1416 / 180.0;
            double x = vertex[i].x;
            double z = vertex[i].z;
            vertex[i].x = cos(rad)*x - sin(rad)*z;
            vertex[i].z = sin(rad)*x + cos(rad)*z;
        }
    }

protected:

    Point3 *vertex;
    int vNum;
    double kd;
    double ks;
    double s;
    RGB color;
};


#endif /* BASEOBJ_H */
