/*
 * File:   bezobj.h
 * Author: Tian-Li Yu
 *
 */

#ifndef BEZOBJ_H
#define BEZOBJ_H


#include <cstdlib>
#include <cstdio>
#include <cstring>
#include "baseobj.h"
#include "bitmap.h"
#include "camera.h"
#include "bezplane.h"
#include "triobj.h"

class BezObj: public BaseObj {
public:

    BezObj(const char* _filename) {
        filename = strdup(_filename);
        read();
    }

    ~BezObj() {
        free(filename);
        delete []bezPlane;
    }

    void draw(const Camera& camera, Bitmap& bmp) const {
        for (int i=0; i<bNum; ++i)
            drawBezPlane(bezPlane[i], camera, bmp);
    }

    void split() {
        BezPlane* bTemp = new BezPlane[bNum * 4];
        Point3* vTemp = new Point3[vNum +  55*bNum];

        for (int i=0; i<vNum; ++i)
            vTemp[i] = vertex[i];

        int bCounter = 0;
        int vCounter = vNum;

        for (int i=0; i<bNum; ++i) {

            int now = vCounter;

            for (int j=0; j<16; j+=4)
                addSplitPoint(vertex[bezPlane[i][j+0]], vertex[bezPlane[i][j+1]], vertex[bezPlane[i][j+2]], vertex[bezPlane[i][j+3]], vTemp, &vCounter);

            addSplitPoint(vertex[bezPlane[i][0]], vertex[bezPlane[i][4]], vertex[bezPlane[i][8]], vertex[bezPlane[i][12]], vTemp, &vCounter);
            for (int j=0; j<5; ++j)
                addSplitPoint(vTemp[now+j+0], vTemp[now+j+5], vTemp[now+j+10], vTemp[now+j+15], vTemp, &vCounter);
            addSplitPoint(vertex[bezPlane[i][3]], vertex[bezPlane[i][7]], vertex[bezPlane[i][11]], vertex[bezPlane[i][15]], vTemp, &vCounter);

            bTemp[bCounter++].init(bezPlane[i][0], now+0, now+1, now+2,
                                   now+20, now+25, now+30, now+35,
                                   now+21, now+26, now+31, now+36,
                                   now+22, now+27, now+32, now+37);

            bTemp[bCounter++].init(now+2, now+3, now+4, bezPlane[i][3],
                                   now+35, now+40, now+45, now+50,
                                   now+36, now+41, now+46, now+51,
                                   now+37, now+42, now+47, now+52);

            bTemp[bCounter++].init(now+22, now+27, now+32, now+37,
                                   now+23, now+28, now+33, now+38,
                                   now+24, now+29, now+34, now+39,
                                   bezPlane[i][12], now+15, now+16, now+17);

            bTemp[bCounter++].init(now+37, now+42, now+47, now+52,
                                   now+38, now+43, now+48, now+53,
                                   now+39, now+44, now+49, now+54,
                                   now+17, now+18, now+19, bezPlane[i][15]);

        }

        delete []vertex;
        delete []bezPlane;

        vertex = vTemp;
        bezPlane = bTemp;

        vNum = vCounter;
        bNum = bCounter;

    }

    void convert2TriObj(TriObj& obj) const {

        obj.init(vNum, bNum * 9 * 2);

        obj.color = color;
        obj.kd = kd;
        obj.ks = ks;
        obj.s = s;

        for (int i=0; i<vNum; ++i)
            obj.vertex[i] = vertex[i];

        int tCounter = 0;
        for (int i=0; i<bNum; ++i) {
            for (int k=0; k<12; k+=4) {
                for (int j=0; j<3; ++j) {
                    obj.triangle[tCounter++].init(bezPlane[i][k+j+0], bezPlane[i][k+j+1], bezPlane[i][k+j+4]);
                    obj.triangle[tCounter++].init(bezPlane[i][k+j+1], bezPlane[i][k+j+5], bezPlane[i][k+j+4]);
                }
            }

        }
    }

protected:

    void addSplitPoint(const Point3& p0, const Point3& p1, const Point3& p2, const Point3& p3, Point3* vTemp, int* counter) {
        Point3 a1 = (p0 + p1) * 0.5;
        Point3 a2 = (p1 + p2) * 0.5;
        Point3 a3 = (p2 + p3) * 0.5;

        Point3 b1 = (a1 + a2) * 0.5;
        Point3 b2 = (a2 + a3) * 0.5;

        Point3 c = (b1 + b2) * 0.5;

        vTemp[(*counter)++] = a1;
        vTemp[(*counter)++] = b1;
        vTemp[(*counter)++] = c;
        vTemp[(*counter)++] = b2;
        vTemp[(*counter)++] = a3;

    }

    void drawBezPlane(const BezPlane& plane, const Camera& camera, Bitmap& bmp) const {
        RGB c(255,255,255);
        Point3 v[16];
        for (int i=0; i<16; ++i)
            v[i] = camera.convert(vertex[plane[i]]);

        for (int i=0; i<16; i+=4) {
            bmp.drawLine(v[i].x, v[i].y, v[i+1].x, v[i+1].y, c);
            bmp.drawLine(v[i+1].x, v[i+1].y, v[i+2].x, v[i+2].y, c);
            bmp.drawLine(v[i+2].x, v[i+2].y, v[i+3].x, v[i+3].y, c);
        }
        for (int i=0; i<4; ++i) {
            bmp.drawLine(v[i].x, v[i].y, v[i+4].x, v[i+4].y, c);
            bmp.drawLine(v[i+4].x, v[i+4].y, v[i+8].x, v[i+8].y, c);
            bmp.drawLine(v[i+8].x, v[i+8].y, v[i+12].x, v[i+12].y, c);
        }
    }

    char* filename;
    int bNum;
    BezPlane *bezPlane;

    void read() {

        double x, y, z;
        int a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p;

        FILE *fp;

        if (!(fp = fopen(filename, "r"))) {
            fprintf(stderr, "Load_patch: Can't open %s\n", filename);
            exit(1);
        }

        (void) fscanf(fp, "%i\n", &bNum);
        bezPlane = new BezPlane[bNum];

        for (int ii = 0; ii < bNum; ++ii) {
            (void) fscanf(fp, "%i, %i, %i, %i,", &a, &b, &c, &d);
            (void) fscanf(fp, "%i, %i, %i, %i,", &e, &f, &g, &h);
            (void) fscanf(fp, "%i, %i, %i, %i,", &i, &j, &k, &l);
            (void) fscanf(fp, "%i, %i, %i, %i\n", &m, &n, &o, &p);
            bezPlane[ii].init(a-1, b-1, c-1, d-1, e-1, f-1, g-1, h-1, i-1, j-1, k-1, l-1, m-1, n-1, o-1, p-1);
        }

        (void) fscanf(fp, "%i\n", &vNum);
        vertex = new Point3[vNum];
        for (int ii = 0; ii < vNum; ++ii) {
            (void) fscanf(fp, "%lf, %lf, %lf\n", &x, &y, &z);
            vertex[ii].x = x;
            vertex[ii].y = y;
            vertex[ii].z = z;
        }
    }

};


#endif  /* BEZOBJ_H */

