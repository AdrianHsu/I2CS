
#include "light.h"
#include "triobj.h"
#include "point3.h"
#include "bezobj.h"
#include "camera.h"
#include "bitmap.h"

using namespace std;


int main() {

    Camera camera(20, 3000);
    Light light(10,10,10,0.3,0.0,0.0,RGB(255,0,255));


    Bitmap map(300,200,"result.bmp");


    BezObj spoon("teaspoon.txt");
    spoon.setProperty(0.5,5,RGB(255,255,100));
    spoon.rotateZ(-90);

    spoon.split();
    spoon.split();
    TriObj tri;
    spoon.convert2TriObj(tri);

    tri.drawFlat(camera, light, map);

    return 0;
}
