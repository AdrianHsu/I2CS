/*
 * File:   light.h
 * Author: Tian-Li Yu
 *
 */

#ifndef LIGHT_H
#define LIGHT_H

#include "point3.h"
#include "rgb.h"

class Light {
public:
    Light(double _x, double _y, double _z, double _Ia, double _alpha, double _beta, const RGB& _color) {
        s.x = _x;
        s.y = _y;
        s.z = _z;
        Ia = _Ia;
        alpha = _alpha;
        beta = _beta;
        v = s;
        v.normalize();
        c = _color;
    }

    double getIntensity(const Point3& target) const {
        if (alpha < 1e-6 && beta < 1e-6)
            return 1.0;
        Point3 v = target - s;
        double distance = sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
        return 1.0/(1.0 + alpha*distance + beta*distance*distance);
    }

    double getAmbient() const {
        return Ia;
    }

    Point3 vector() const {
        return v;
    }

    RGB color() const {
        return c;
    }

protected:
    double Ia;
    double alpha;
    double beta;
    // source
    Point3 s;
    // normalized vector
    Point3 v;
    // color
    RGB c;

};

#endif /* LIGHT_H */

