/*
 * File:   bplane.h
 * Author: Tian-Li Yu
 *
 * Last updated on 2012/04/30
 * For I2CS course
 *
 */

#ifndef BEZPLANE_H
#define BEZPLANE_H

class BezPlane {
public:
    BezPlane() {
        v = new int[16];
    }

    ~BezPlane() {
        delete []v;
    }

    void init(int a, int b, int c, int d, int e, int f, int g, int h, int i, int j, int k, int l, int m, int n, int o, int p) {
        v[0] = a;
        v[1] = b;
        v[2] = c;
        v[3] = d;
        v[4] = e;
        v[5] = f;
        v[6] = g;
        v[7] = h;
        v[8] = i;
        v[9] = j;
        v[10] = k;
        v[11] = l;
        v[12] = m;
        v[13] = n;
        v[14] = o;
        v[15] = p;
    }

    int operator[] (int index) const {
        return v[index];
    }

protected:
    int *v;

};

#endif  /* BEZPLANE_H */

