#include <cstdio>
#include <ctime>

int reverse_asm( int num ) {
    int result;
    asm volatile(".intel_syntax;\n"
    // ===== add your codes here =====
        " mov   eax,    %1  ;\n"

        " mov    %0,   eax  ;\n"
    // =====---------------------=====
        ".att_syntax;\n" : "=r" (result) : "r" (num) : "%eax","%ebx","%ecx","%edx" // you can modify this line if needed
    );
    return result ;
}
int reverse_cpp( int num ){
    int result = 0;
    int length = 0;

    int stack[10];
    int stackCounter = 0;

    for(int rem=num;rem>0;++length){
        stack[stackCounter++] = rem%10; // you can view this as push
        rem /= 10;
    }

    int shift = 1;
    for(int i=0;i<length;++i){
        result += shift*stack[--stackCounter]; // you can view this as pop
        shift *= 10;
    }

    return result ;
}

#define CASENUM 1000000
#define NUM 0
void evaluate(){
    int* golden = new int[CASENUM];
    int* ans    = new int[CASENUM];
    double cpp_time,asm_time;
    clock_t start;
    //===== run asm function  =====
    start = clock();
    for(int i=0,numA=NUM;i<CASENUM;++i,++numA){
        ans[i]=reverse_asm(numA);
    }
    asm_time = double(clock()-start)/CLOCKS_PER_SEC;
    //===== run cpp function =====
    start = clock();
    for(int i=0,numA=NUM;i<CASENUM;++i,++numA){
        golden[i]=reverse_cpp(numA);
    }
    cpp_time = double(clock()-start)/CLOCKS_PER_SEC;
    //===== checking =====
    int error = 0;
    for(int i=0;i<CASENUM;++i){
        if(ans[i]!=golden[i]) ++error;
        if(ans[i]!=golden[i] && error==1) printf("first error at %d: %d(cpp)!=%d(asm)\n",i,golden[i],ans[i]);
    }
    if(error==0){
        if(asm_time<cpp_time) printf("Congratulation!!, you pass the bonus work ^_^ \n");
        else printf("You pass the basic problem, it's near the bonus requirement >w< \n");
    }else printf("there are %d error(s) T^T \n",error);


    printf("cpp_time = %f sec for %d times\n",cpp_time,CASENUM);
    printf("asm_time = %f sec for %d times\n",asm_time,CASENUM);

    delete [] ans;
    delete [] golden;
}

int main(){
    //int num = 123456;
    //printf("result: %d\n",reverse_asm(num));
    //printf("result: %d\n",reverse_cpp(num));

    evaluate();

    return 0;
}
