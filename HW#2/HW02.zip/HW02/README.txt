README

作者資訊
電機一 許秉鈞
B03901023

"I FINISHED THE BONUS PART(O2)!"

編譯環境
g++ on cygwin64 (Windows x64)
CPPFLAGS = -O2 -std=c++11 -Wall

設置指引
根據makefile指示如下:

base8 基本題:

make base8_basic
make run_basic

base8 O2加分題:

make base8_bonus
make run_bouns


檔案列表（隨著軟件而發佈的檔案）

base8_basic.cpp //代表基本題
base8.cpp //代表加分題
makefile
README.txt

已知臭蟲
暫無

更新記錄

【2014.03.26】
作業完成

花費時間
約8hrs

網站資源
Cplusplus.com

特別感謝
謝明倫助教
